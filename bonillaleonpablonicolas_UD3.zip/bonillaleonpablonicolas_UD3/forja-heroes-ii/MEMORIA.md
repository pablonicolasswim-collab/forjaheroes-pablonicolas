# Memoria · Tarea de refuerzo UD3 «Forja de Héroes II»

**Alumno/a:** Completar · **Variante:** A (confirma la asignada en clase) · **Fecha:** completar

> Esta tarea *lleva nota**: sirve para comprobar que dominas lo que necesitarás en la UD5 (sesiones y login) y para preparar la prueba de diagnóstico del RA 3. Las capturas van en `capturas/` y se enlazan así: `![descripción](capturas/nombre.png)`

## 1. Comprobación de resultados

**Variante A: La Cripta de los Ecos.** Los resultados de la página coinciden con la tabla del enunciado.

| Dato | Valor esperado (enunciado) | Valor de mi página | ¿Coincide? |
|---|---|---|---|
| Poder total de la party | 1.243 | 1.243 | Sí |
| Daño por ronda | 205,6 | 205,6 | Sí |
| Líder | Aldric | Aldric | Sí |
| Vida al salir de las salas | 305 de 774 | 305 de 774 | Sí |
| Resultado frente al jefe (y ronda) | Victoria en la ronda 5 | Victoria en la ronda 5 | Sí |
| Oro final | 2.260,75 mo | 2.260,75 mo | Sí |
| Valor del inventario | 151,20 mo | 151,20 mo | Sí |
| Salas en el mapa | 7 | 7 | Sí |

## 2. Bucles y documento resultante

![Código de la tabla](capturas/foreach.png)

![Tabla en Ctrl+U](capturas/ctrl-u.png)

- Hay una fila `<tr>` en la plantilla de PHP. El `foreach` la genera cuatro veces, una por héroe; la cabecera es otra fila aparte. Se ven cinco filas en total.
- En Ctrl+U aparecen las cuatro filas de héroes porque el navegador recibe el HTML generado por PHP. No aparecen `endforeach` ni `if`: esas instrucciones se ejecutan en el servidor.


## 3. Experimento: predigo el efecto de un cambio

Añade esta sala **al principio** de `$salas` en tu fichero de datos:

```php
['nombre' => 'Derrumbe', 'tipo' => 'combate', 'valor' => 2400],
```

1. **Predicción:** al añadir la sala al principio, se explora una sola sala. El combate resta 600 de vida (2400 dividido entre 4) y deja a la party sin vida. El jefe da **Derrota (no llegó)**; quedan 7 salas pendientes.
2. **Resultado y captura:** realiza la prueba en tu ordenador y guarda la captura en `capturas/derrumbe.png`.
3. El `break` que va después del `switch` detiene el `foreach` cuando la vida de la party llega a 0. No aparece tabla de rondas porque la party no llega a combatir con el jefe.
4. Después de la prueba, quita la sala añadida y deja `datos-A.php` como estaba.

## 4. Experimento: match frente a switch

1. **Resultado esperado:** al cambiar la clase a `'Bardo'`, el `match` lanza `UnhandledMatchError`: no existe un caso `'Bardo'` y el `match` no lleva `default`. Realiza la prueba en tu ordenador y guarda la captura en `capturas/bardo.png`.
2. El `switch` asigna al Bardo la posición «Reserva» porque tiene un caso `default`. El `switch` no falla por esa posición, pero sí falla el `match` usado antes para calcular el daño.
3. Restaura la clase original. En un programa real añadiría validación o un tratamiento claro para una clase desconocida, para evitar que el error detenga la página.

## 5. Experimento: continue dentro de switch

1. **Aviso esperado:** si cambias `continue 2;` por `continue;`, PHP muestra un `E_WARNING`, porque `continue` dentro de un `switch` se interpreta como `break`. Realiza la prueba en tu ordenador y guarda la captura en `capturas/continue.png`.
2. `continue 2;` sale del `switch` y pasa a la siguiente sala del `foreach`. `continue;` sale solo del `switch`; después se ejecuta la comprobación de vida. En esta sala vacía, el diario y el recuento siguen incluyendo una sala.
3. Restaura `continue 2;` como estaba.

## 6. Uso de IA (obligatorio declararlo)

Sí, he usado una IA para completar y revisar los cálculos del ejercicio y preparar las explicaciones de la memoria. Le pregunté qué hace `continue 2;` dentro de un `switch` que está dentro de un `foreach`. Respondió que pasa a la siguiente sala, saltándose el resto del `switch`; la explicación es correcta.
