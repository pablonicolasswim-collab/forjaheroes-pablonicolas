<?php
/**
 * Informe de expedición de La Forja de Héroes II.
 * Autor/a: completar con el nombre del alumno.
 * Variante: A (confirmar que es la asignada en el aula).
 */
declare(strict_types=1);

require_once __DIR__ . '/inc/reglas.php';
require_once __DIR__ . '/inc/datos-' . VARIANTE . '.php';

// Se calculan los datos de cada héroe para presentar la party completa.
# Los datos calculados se guardan en el mismo héroe.
foreach ($party as $i => $heroe) {
    $nivel = intdiv($heroe['xp'], XP_POR_NIVEL) + 1;
    $vidaMax = VIDA_BASE + $heroe['constitucion'] * $nivel * MULT_VIDA[$heroe['clase']];
    $pctVida = $vidaMax > 0 ? $heroe['vida'] / $vidaMax * 100 : 0;

    $danio = match ($heroe['clase']) {
        'Guerrera' => $heroe['fuerza'] ** 2 / 10 + $nivel * 2,
        'Hechicero' => $heroe['inteligencia'] * 3 + $nivel ** 2 / 4,
        'Pícara' => $heroe['destreza'] * 2 + $nivel ** 1.5,
        'Clérigo' => ($heroe['inteligencia'] + $heroe['constitucion']) * 1.5 + $nivel,
    };

    if ($heroe['vida'] <= 0) {
        $estado = 'K.O.';
    } elseif ($pctVida < 35) {
        $estado = 'En peligro';
    } elseif ($pctVida < 70) {
        $estado = 'Herido';
    } else {
        $estado = 'En pie';
    }

    switch ($heroe['clase']) {
        case 'Guerrera':
        case 'Clérigo':
            $posicion = 'Primera línea';
            break;
        case 'Pícara':
            $posicion = 'Flanco';
            break;
        case 'Hechicero':
            $posicion = 'Retaguardia';
            break;
        default:
            $posicion = 'Reserva';
    }

    $bloquesLlenos = (int) round($pctVida / 100 * BLOQUES_BARRA);
    $barra = '';
    for ($bloque = 0; $bloque < BLOQUES_BARRA; $bloque++) {
        $barra .= $bloque < $bloquesLlenos ? '█' : '░';
    }

    $party[$i]['nivel'] = $nivel;
    $party[$i]['vidaMax'] = $vidaMax;
    $party[$i]['pctVida'] = $pctVida;
    $party[$i]['danio'] = $danio;
    $party[$i]['poder'] = (int) round($danio * $nivel);
    $party[$i]['estado'] = $estado;
    $party[$i]['posicion'] = $posicion;
    $party[$i]['barra'] = $barra;
}

// Los totales se calculan a partir de las estadísticas individuales.
$vidaParty = array_sum(array_column($party, 'vida'));
$vidaMaxParty = array_sum(array_column($party, 'vidaMax'));
$poderParty = array_sum(array_column($party, 'poder'));
$nivelMedio = array_sum(array_column($party, 'nivel')) / count($party);
$danioParty = 0.0;
$heroesActivos = 0;
$lider = null;
foreach ($party as $heroe) {
    if ($heroe['estado'] === 'K.O.') {
        continue ;
    }
    $danioParty += $heroe['danio'];
    $heroesActivos++;
    if ($lider === null || $heroe['poder'] > $lider['poder']) {
        $lider = $heroe;
    }
}
$clasesParty = array_column($party, 'clase');
$hayPicara = in_array('Pícara', $clasesParty, true);
$hayClerigo = in_array('Clérigo', $clasesParty, true);

/* La expedición actualiza el oro, la vida y el diario al recorrer las salas. */
$oro = $oroInicial;
$xpGanada = 0;
$diario = [];
$salasExploradas = 0;
foreach ($salas as $n => $sala) {
    $salasExploradas++;
    switch ($sala['tipo']) {
        case 'vacía':
            $diario[] = 'Sala ' . ($n + 1) . ' · ' . $sala['nombre'] . ': vacía, la party sigue avanzando.';
            continue 2;

        case 'trampa':
            if ($hayPicara) {
                $diario[] = 'Sala ' . ($n + 1) . ' · ' . $sala['nombre'] . ': ¡trampa evitada por la Pícara!';
            } else {
                $vidaParty -= $sala['valor'];
                $diario[] = 'Sala ' . ($n + 1) . ' · ' . $sala['nombre'] . ': ¡trampa! −' . $sala['valor'] . ' de vida.';
            }
            break;

        case 'combate':
            $danioSala = intdiv($sala['valor'], 4);
            $vidaParty -= $danioSala;
            $xpGanada += $sala['valor'];
            $diario[] = 'Sala ' . ($n + 1) . ' · ' . $sala['nombre'] . ': combate, −' . $danioSala . ' de vida y +' . $sala['valor'] . ' XP.';
            break;

        case 'tesoro':
            $oro += $sala['valor'];
            $textoTesoro = 'Sala ' . ($n + 1) . ' · ' . $sala['nombre'] . ': tesoro, +' . number_format($sala['valor'], 2, ',', '.') . ' mo';
            if (isset($sala['objeto'])) {
                if (!isset($inventario[$sala['objeto']])) {
                    $inventario[$sala['objeto']] = 0;
                }
                $inventario[$sala['objeto']]++;
                $textoTesoro .= ' y «' . $sala['objeto'] . '»';
            }
            $diario[] = $textoTesoro . '.';
            break;

        case 'descanso':
            $curacion = $sala['valor'] * ($hayClerigo ? 2 : 1);
            $vidaAnterior = $vidaParty;
            $vidaParty = min($vidaMaxParty, $vidaParty + $curacion);
            $vidaCurada = $vidaParty - $vidaAnterior;
            $detalleCuracion = $hayClerigo ? ' (bendición del Clérigo)' : '';
            $diario[] = 'Sala ' . ($n + 1) . ' · ' . $sala['nombre'] . ': descanso, +' . $vidaCurada . ' de vida' . $detalleCuracion . '.';
            break;
    }

    if ($vidaParty <= 0) {
        $vidaParty = 0;
        $diario[] = 'La party se queda sin vida y no puede continuar.';
        break;
    }
}
$salasPendientes = count($salas) - $salasExploradas;

// Se simula el combate por rondas y se suma el premio si hay victoria.
$tieneLlave = array_key_exists($jefe['llave'], $inventario);
$golpe = (int) round($danioParty);
$rondas = [];
$rondaFinal = 0;
if ($vidaParty <= 0) {
    $resultado = 'Derrota';
    $motivoJefe = 'La party no llegó a la guarida.';
} elseif (!$tieneLlave) {
    $resultado = 'Puerta sellada';
    $motivoJefe = 'Falta la llave «' . $jefe['llave'] . '».';
} else {
    $vidaJefe = $jefe['vida'];
    while ($vidaJefe > 0 && $vidaParty > 0 && $rondaFinal < MAX_RONDAS) {
        $rondaFinal++;
        $vidaJefe = max(0, $vidaJefe - max(0, $golpe));
        if ($vidaJefe > 0) {
            $vidaParty = max(0, $vidaParty - max(0, $jefe['ataque']));
        }
        $rondas[] = [
            'ronda' => $rondaFinal,
            'vidaJefe' => $vidaJefe,
            'vidaParty' => $vidaParty,
        ];
    }

    $resultado = match (true) {
        $vidaJefe <= 0 => 'Victoria',
        $vidaParty <= 0 => 'Derrota',
        default => 'Retirada',
    };
    $motivoJefe = match ($resultado) {
        'Victoria' => 'La party derrotó al jefe en la ronda ' . $rondaFinal . '.',
        'Derrota' => 'El jefe venció a la party.',
        default => 'La party se retiró tras ' . $rondaFinal . ' rondas.',
    };
    if ($resultado === 'Victoria') {
        $oro += $jefe['recompensa'];
    }
}

// Se calcula el inventario final después de obtener los tesoros de las salas.
$valorInventario = 0.0;
foreach ($inventario as $objeto => $cantidad) {
    $valorInventario += $cantidad * $precios[$objeto];
}
$totalObjetos = array_sum($inventario);
$inventarioOrdenado = $inventario;
arsort($inventarioOrdenado);
$objetoMasAbundante = $inventarioOrdenado === [] ? 'Ninguno' : (string) array_key_first($inventarioOrdenado);

// Se cuentan las celdas para comprobar que el mapa contiene las salas indicadas.
$conteoCeldas = [];
for ($fila = 0; $fila < count($mapa); $fila++) {
    for ($columna = 0; $columna < count($mapa[$fila]); $columna++) {
        $celda = $mapa[$fila][$columna];
        $conteoCeldas[$celda] = ($conteoCeldas[$celda] ?? 0) + 1;
    }
}
$mapaCoherente = ($conteoCeldas['S'] ?? 0) === count($salas);
$bloquesParty = $vidaMaxParty > 0 ? (int) round($vidaParty / $vidaMaxParty * BLOQUES_BARRA) : 0;
$barraParty = '';
for ($bloque = 0; $bloque < BLOQUES_BARRA; $bloque++) {
    $barraParty .= $bloque < $bloquesParty ? '█' : '░';
}
$claseResultado = in_array($resultado, ['Victoria', 'Retirada'], true) ? 'vida' : 'peligro';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Expedición · <?= htmlspecialchars($nombreMazmorra, ENT_QUOTES, 'UTF-8') ?> · Forja de Héroes II</title>
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>
<main>
    <span class="insignia">VARIANTE <?= htmlspecialchars(VARIANTE, ENT_QUOTES, 'UTF-8') ?></span>
    <h1><?= htmlspecialchars($nombreMazmorra, ENT_QUOTES, 'UTF-8') ?></h1>
    <p class="subtitulo">Informe de expedición · líder: <?= htmlspecialchars($lider['nombre'] ?? 'Ninguno', ENT_QUOTES, 'UTF-8') ?></p>

    <h2>La party</h2>
    <table>
        <tr><th>Héroe</th><th>Clase</th><th>Nivel</th><th>Vida</th><th>Daño</th><th>Poder</th><th>Posición</th><th>Estado</th></tr>
        <?php foreach ($party as $heroe): ?>
        <tr>
            <td><?= htmlspecialchars($heroe['nombre'], ENT_QUOTES, 'UTF-8') ?></td>
            <td><?= htmlspecialchars($heroe['clase'], ENT_QUOTES, 'UTF-8') ?></td>
            <td><?= $heroe['nivel'] ?></td>
            <td><span class="barra mini"><?= $heroe['barra'] ?></span> <?= $heroe['vida'] ?>/<?= $heroe['vidaMax'] ?></td>
            <td><?= number_format($heroe['danio'], 1, ',', '.') ?></td>
            <td><?= $heroe['poder'] ?></td>
            <td><?= htmlspecialchars($heroe['posicion'], ENT_QUOTES, 'UTF-8') ?></td>
            <?php if ($heroe['estado'] === 'K.O.' || $heroe['estado'] === 'En peligro'): ?>
            <td class="peligro"><?= htmlspecialchars($heroe['estado'], ENT_QUOTES, 'UTF-8') ?></td>
            <?php else: ?>
            <td class="vida"><?= htmlspecialchars($heroe['estado'], ENT_QUOTES, 'UTF-8') ?></td>
            <?php endif; ?>
        </tr>
        <?php endforeach; ?>
    </table>

    <div class="rejilla">
        <div class="stat"><div class="etq">Poder total</div><div class="val"><?= $poderParty ?></div></div>
        <div class="stat"><div class="etq">Nivel medio</div><div class="val"><?= number_format($nivelMedio, 1, ',', '.') ?></div></div>
        <div class="stat"><div class="etq">Daño por ronda</div><div class="val"><?= number_format($danioParty, 1, ',', '.') ?></div></div>
        <div class="stat"><div class="etq">Héroes activos</div><div class="val"><?= $heroesActivos ?> / <?= count($party) ?></div></div>
    </div>

    <h2>Diario de la expedición</h2>
    <ol class="diario">
        <?php foreach ($diario as $linea): ?>
        <li><?= htmlspecialchars($linea, ENT_QUOTES, 'UTF-8') ?></li>
        <?php endforeach; ?>
    </ol>
    <p>Salas exploradas: <?= $salasExploradas ?> de <?= count($salas) ?>
        <?php if ($salasPendientes > 0): ?>
        · <span class="peligro">Quedan <?= $salasPendientes ?> salas sin explorar</span>
        <?php endif; ?>
        · XP ganada: <?= $xpGanada ?></p>

    <h2>El jefe: <?= htmlspecialchars($jefe['nombre'], ENT_QUOTES, 'UTF-8') ?></h2>
    <p>Vida <?= $jefe['vida'] ?> · ataque <?= $jefe['ataque'] ?> · golpe de la party: <?= $golpe ?> por ronda</p>
    <?php if ($rondas !== []): ?>
    <table>
        <tr><th>Ronda</th><th>Vida del jefe</th><th>Vida de la party</th></tr>
        <?php foreach ($rondas as $datosRonda): ?>
        <tr><td><?= $datosRonda['ronda'] ?></td><td><?= $datosRonda['vidaJefe'] ?></td><td><?= $datosRonda['vidaParty'] ?></td></tr>
        <?php endforeach; ?>
    </table>
    <?php endif; ?>
    <p class="resultado <?= $claseResultado ?>"><strong><?= htmlspecialchars($resultado, ENT_QUOTES, 'UTF-8') ?></strong> · <?= htmlspecialchars($motivoJefe, ENT_QUOTES, 'UTF-8') ?></p>
    <p class="barra vida">PARTY <?= $barraParty ?> <?= $vidaParty ?>/<?= $vidaMaxParty ?></p>

    <h2>Inventario</h2>
    <table>
        <tr><th>Objeto</th><th>Cantidad</th><th>Precio</th><th>Subtotal</th></tr>
        <?php foreach ($inventarioOrdenado as $objeto => $cantidad): ?>
        <tr>
            <td><?= htmlspecialchars((string) $objeto, ENT_QUOTES, 'UTF-8') ?></td>
            <td><?= $cantidad ?></td>
            <td><?= number_format($precios[$objeto], 2, ',', '.') ?> mo</td>
            <td><?= number_format($cantidad * $precios[$objeto], 2, ',', '.') ?> mo</td>
        </tr>
        <?php endforeach; ?>
    </table>
    <div class="rejilla">
        <div class="stat"><div class="etq">Objetos</div><div class="val"><?= $totalObjetos ?></div></div>
        <div class="stat"><div class="etq">Valor del inventario</div><div class="val"><?= number_format($valorInventario, 2, ',', '.') ?> mo</div></div>
        <div class="stat"><div class="etq">Oro final</div><div class="val"><?= number_format($oro, 2, ',', '.') ?> mo</div></div>
        <div class="stat"><div class="etq">Más abundante</div><div class="val peq"><?= htmlspecialchars($objetoMasAbundante, ENT_QUOTES, 'UTF-8') ?></div></div>
    </div>

    <h2>Mapa de la mazmorra</h2>
    <table class="mapa">
        <?php foreach ($mapa as $fila): ?>
        <tr>
            <?php foreach ($fila as $celda): ?>
            <td class="<?= htmlspecialchars(LEYENDA_MAPA[$celda][0], ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($celda, ENT_QUOTES, 'UTF-8') ?></td>
            <?php endforeach; ?>
        </tr>
        <?php endforeach; ?>
    </table>
    <p>
        <?php foreach (LEYENDA_MAPA as $celda => $datosLeyenda): ?>
            <?= htmlspecialchars($datosLeyenda[1], ENT_QUOTES, 'UTF-8') ?> (<?= htmlspecialchars($celda, ENT_QUOTES, 'UTF-8') ?>): <?= $conteoCeldas[$celda] ?? 0 ?><?= $celda === array_key_last(LEYENDA_MAPA) ? '' : ' · ' ?>
        <?php endforeach; ?>
    </p>
    <p>
        <?php if ($mapaCoherente): ?>
        El mapa es coherente: el número de salas coincide.
        <?php else: ?>
        El mapa no es coherente: el número de salas no coincide.
        <?php endif; ?>
    </p>

    <footer>Informe generado el <?= date('d/m/Y H:i') ?> con PHP <?= htmlspecialchars(PHP_VERSION, ENT_QUOTES, 'UTF-8') ?> · cada recarga lo recalcula todo desde cero.</footer>
</main>
</body>
</html>
